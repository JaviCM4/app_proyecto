// Archivo GENERADO por scripts/generar-env.mjs a partir de .env. No editar a mano.
export const environment = {
  "production": false,
  "apiUrl": "http://localhost:8080",
  "appNombre": "Transportes Esmeralda"
};
